<?php
// 引入判断文件
require("./cloaka/ip_check.php");
require_once("./cloaka/ip_check.php");

require_once("index.html");
?>