var line_list = [
    "https://line.me/ti/p/pFKooRdO0X",
    "https://line.me/ti/p/PPP3z4xSIL"
];